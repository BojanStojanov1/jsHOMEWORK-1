let numberOfPhones = "30"
console.log("Number of Phones:")
console.log(numberOfPhones)
let priceOfPhones = "119.95"
console.log("the price of one phone is:")
console.log(priceOfPhones)
let sumOfPrice = numberOfPhones * priceOfPhones
console.log("the sum of all the phones without tax is:")
console.log(sumOfPrice)
let a = 100
let percent = 5
let totalPercent= (percent/a)*sumOfPrice
console.log("the 5% tax for the phones in dollars is:")
console.log(totalPercent)
let fullPrice = sumOfPrice + totalPercent
console.log( "the full price of the phones is :" ) ;
console.log(fullPrice)